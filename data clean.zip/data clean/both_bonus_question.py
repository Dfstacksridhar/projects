

class users():
    def __init__(self,name_list,mark_list):
        self.name_list=name_list
        self.mark_list=mark_list
    def paren(self,input_list):
          if input_list[0][:-1] in ['final','midterm']:
              self.value= (float(input_list[2][1:-2])+float(input_list[4][1:-2]))/2
          else:
              self.value= input_list[-1][1:-2]
    def name_append(self):
               self.last_name=(self.name_list[1][:-1])
               self.first_name=(self.name_list[2])
               self.username=(self.name_list[4][:self.name_list[4].find('@')])
               self.course=(self.name_list[0][:-2])
               self.cs_account=(self.name_list[0])
    def mark_append(self):
               for self.line in self.mark_list:
                       self.paren(self.line.replace("============================================================",'').split())
                       exec("self.%s = %f" %(self.line.split()[0][:-1],float(self.value)))
class parse_data():
    def __init__(self,file_path):
        self.sep1="============================================================\n"
        self.sep2="------------------------------------------------------------\n"
        self.file_path=file_path
        self.data=[]
        with open(self.file_path) as readfl:
            for line in readfl.read().strip().split(self.sep1):
                self.data.append(line.split(self.sep2))

    def data_traverse(self):
        self.username=[]
        for line in self.data:
            name_text=line[0].replace('-','').split()
            entity=name_text[0]
            entity=users(name_text,line[1:])
            entity.name_append()
            self.username.append(entity)
            entity.mark_append()
            del entity.mark_list
            del entity.value
            del entity.name_list
            del entity.line
def letter_grade(score):
    score=float(score)

    if score >= 97:
        return "A+"
    if score >= 93:
        return "A"
    if score >= 90:
        return "A-"
    if score >= 87:
        return "B+"
    if score >= 83:
        return "B"
    if score >= 83:
        return "B"
    if score >= 80:
        return "B-"
    if score >= 77:
        return "C+"
    if score >=73:
        return "C"
    if score >=70:
        return "C-"
    if score >=67:
        return "D+"
    if score >=63:
        return "D"
    if score >=60:
        return "D-"

    #
    # COMPLETE THIS
    #

    return "F"
usernames=[]
for file1 in ['cs002','cs007']:
  file=parse_data(f'{file1}.txt')
  file.data_traverse()
  usernames=usernames+file.username
labels=[ x for x in list(vars(usernames[0]).keys())]
usernames.sort(key=lambda x:x.last_name)
with open(f'bothb.csv','w') as writefl:
      for line in labels:
          writefl.write(line)
          if line!='quiz4':
              writefl.write(',')
          else:
              writefl.write('\n')
      for x in usernames:
          for y in labels:
              #value=(x.__getattribute__(y))
              if 'lab6' not in vars(x) and y=='lab6':
                  writefl.write('')
              else:
                    value=(x.__getattribute__(y))
                    writefl.write(letter_grade(value) if type(value) is not str else str(value))
              if y !='quiz4':
                  writefl.write(',')
              else:
                  writefl.write('\n')
