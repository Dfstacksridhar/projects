

class users():# creating the class for the users
    def __init__(self,name_list,mark_list):
        self.name_list=name_list # Initialize with name_list and mark_list
        self.mark_list=mark_list
    def paren(self,input_list):# removing the parens from the input data
          if input_list[0][:-1] in ['final','midterm']:
              self.value= (float(input_list[2][1:-2])+float(input_list[4][1:-2]))/2# calc the final and midterm
          else:
              self.value= input_list[-1][1:-2]# Accessing the per value from the input vvalue
    def name_append(self):# method to create the attr for the object related to user information(users)
               self.last_name=(self.name_list[1][:-1])# setting the attributes for the users(ex :cs00201)
               self.first_name=(self.name_list[2])
               self.username=(self.name_list[4][:self.name_list[4].find('@')])
               self.course=(self.name_list[0][:-2])
               self.cs_account=(self.name_list[0])
    def mark_append(self):# method to create the attr for the object related to marks(users)
               for self.line in self.mark_list:
                       self.paren(self.line.replace("============================================================",'').split())
                       exec("self.%s = %f" %(self.line.split()[0][:-1],float(self.value)))#setting the attributes for attri related to mark
class parse_data():# creating the class for the file and parsing the data
    def __init__(self,file_path):# initialize the object
        self.sep1="============================================================\n"
        self.sep2="------------------------------------------------------------\n"
        self.file_path=file_path
        self.data=[]
        with open(self.file_path) as readfl:
            for line in readfl.read().strip().split(self.sep1):
                self.data.append(line.split(self.sep2))## splitting the raw text based on the sep1 , sep 2 and setting the value for the attr

    def data_traverse(self):
        self.username=[]
        for line in self.data:
            name_text=line[0].replace('-','').split()
            entity=name_text[0]
            entity=users(name_text,line[1:])# initialize the user class (parse_data1) with args as name info and marl info
            entity.name_append()
            self.username.append(entity)#storing the object in the list for the writing into csv later
            entity.mark_append()
            del entity.mark_list# removing the unwanted attr from the object to use the vars function in write method later
            del entity.value
            del entity.name_list
            del entity.line
def letter_grade(score):
    score=float(score)

    if score >= 97:
        return "A+"
    if score >= 93:
        return "A"
    if score >= 90:
        return "A-"
    if score >= 87:
        return "B+"
    if score >= 83:
        return "B"
    if score >= 83:
        return "B"
    if score >= 80:
        return "B-"
    if score >= 77:
        return "C+"
    if score >=73:
        return "C"
    if score >=70:
        return "C-"
    if score >=67:
        return "D+"
    if score >=63:
        return "D"
    if score >=60:
        return "D-"

    #
    # COMPLETE THIS
    #

    return "F"

for file1 in ['cs002','cs007']:
  file=parse_data(f'{file1}.txt')#initialize with raw text
  file.data_traverse()
  labels=[ x for x in list(vars(file.username[0]).keys())]#creating the labels based on the object attr
  with open(f'{file1}.csv','w') as writefl:# writing the labels to the file
      for line in labels:
          writefl.write(line)
          if line!='quiz4':
              writefl.write(',')
          else:
              writefl.write('\n')
      for x in file.username:# writing the data to the file
          for y in labels:
              value=(x.__getattribute__(y))
              writefl.write(letter_grade(value) if type(value) is not str else str(value))
              if y !='quiz4':
                  writefl.write(',')
              else:
                  writefl.write('\n')
