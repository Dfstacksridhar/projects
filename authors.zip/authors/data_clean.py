def funcDataClean(filenm):
 index=[]
 with open(f'{filenm}.txt') as txtfl:
    lines=txtfl.readlines()
    for lineno,x in enumerate(lines,1):
        if "*** START OF TH" in x:
            index.append(lineno)
        elif "*** END" in x:
            index.append(lineno)
        elif len(index)==2:
            break
        else:
            pass
    lines=lines[index[0]:index[1]]
    return lines
