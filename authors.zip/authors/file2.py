def count():
 count=0
 indexList=[]
 lines=[]
 with open('Jean-Henri-Fabre-04.txt') as txtfl:
    for x in txtfl:
     count+=1
     if "*** START OF TH" in x:
         indexList.append(count)
     elif "*** END" in x:
         indexList.append(count)
     elif len(indexList)==1:
         lines.append(x)
     elif len(indexList)==2:
         break
     else:
         pass
    return indexList,lines

v=count()
print(*v[1],sep='\n')
