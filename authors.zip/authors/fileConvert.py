import re
from data_clean import funcDataClean as clean

lambdaSlice={'sliceEnd':lambda x:x[:-1] if x[-1] in [',','.',':',';'] else x,
             'sliceFront':lambda x:re.sub(r'[^a-zA-Z]',r"",x) if not str.isalpha(x[0]) else x,
             'slice':lambda x:re.sub(r"\n|—|-"," ",x).split(" "),
              'stopIndex':lambda x:l}


def count(lines):
    dictvl={}
    for line in lines:
        for word in lambdaSlice['slice'](line):
            if len(word)>2:
              word=lambdaSlice['sliceFront']((lambdaSlice['sliceEnd'](word)).lower())
              if str.isalpha(word):
               if word not in dictvl:
                  dictvl[word]=0
               dictvl[word]+=1
    return sorted(dictvl.items(),key=lambda x:dictvl[x[0]],reverse=True),sum(dictvl.values())

def create_csv(filename,Value,sum):
  with open(f"{filename}.csv",'w') as f:
      avg=sum/len(Value)
      for x in Value:
        if x[1]<avg:
            break
        value=x[0]+','+str(x[1])+','
        f.write(value)
        f.write('%f' %float(x[1]/sum))
        f.write("\n")

if __name__=="__main__":
     for name in ['Graham-George','Jean-Henri-Fabre']:#'Jean-Henri-Fabre
         for x in range(1,6):
             filenm=f'{name}-0{x}' if x<5 else f'{name}-unknown'
             lines=clean(filenm)
             create_csv(filenm,*count(lines))
